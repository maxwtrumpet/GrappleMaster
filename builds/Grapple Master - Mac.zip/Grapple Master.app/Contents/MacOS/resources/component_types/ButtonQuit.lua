ButtonQuit = {
    OnClick = function (self)
        Application.Quit()
    end
}