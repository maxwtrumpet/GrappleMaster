ButtonMenu = {
    OnClick = function (self)
        Scene.Load("menu")
    end
}